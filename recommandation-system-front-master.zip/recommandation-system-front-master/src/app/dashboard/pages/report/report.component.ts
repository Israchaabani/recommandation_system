import { Component, OnInit, ViewChild } from '@angular/core';
import { Chart, registerables } from 'chart.js';
import { ReportDataService } from 'src/app/services/report-data.service';
Chart.register(...registerables);

@Component({
  selector: 'app-report',
  templateUrl: './report.component.html',
  styleUrls: ['./report.component.css']
})
export class ReportComponent implements OnInit {
  @ViewChild('pop') canvas: any;
  @ViewChild('pop2') canvas2: any;
  @ViewChild('pop3') canvas3: any;
  @ViewChild('pop4') canvas4: any;
  chart: any;
  label: any;
  data: any;

  reportData: any;
  objTest = {
    by_category: [{Category: 'Clothing', Quantity: 3516},
    {Category: 'Electronics', Quantity: 1154},
    {Category: 'Furniture', Quantity: 945}],
    by_sub_category: [
      {"Sub-Category": 'Saree', Quantity: 782},
      {"Sub-Category": 'Hankerchief', Quantity: 754},
      {"Sub-Category": 'Stole', Quantity: 671}
    ],
    group_by: [    
      {Category: 'Clothing', 'Sub-Category': 'Saree', Quantity: 782},
      {Category: 'Clothing', 'Sub-Category': 'Hankerchief', Quantity: 754},
      {Category: 'Clothing', 'Sub-Category': 'Stole', Quantity: 671}
    ]
  };
  constructor(private report: ReportDataService) { }

  ngOnInit(): void {
    this.data = [65, 59, 80, 81, 56, 55, 40];
    this.label = ['janv', 'fev', 'mar', 'avr', 'mai', 'ju', 'jul'];

    this.getValues();
  }


  ngAfterViewInit() {
    setTimeout(
      () => {
        console.log(this.getLabels(this.objTest.by_sub_category, 'subcategory'));
        console.log(this.getValuesChart(this.objTest.by_sub_category));
        console.log(this.getLabelsSpecific(this.objTest.group_by));
        
        
        this.setChart(this.getLabels(this.objTest.by_category, 'category'), this.getValuesChart(this.objTest.by_category));  
        this.setChart2(this.getLabels(this.objTest.by_sub_category, 'subcategory'), this.getValuesChart(this.objTest.by_sub_category));        
      
      }, 800
    )
  }


  getLabels(obj: any, type: any) {
    let arr = [];

    for (let i = 0; i < obj.length; i++) { 

      if (type === 'category') arr.push(obj[i].Category);
      if (type === 'subcategory') arr.push(obj[i]['Sub-Category'])
    }

    return arr;    
  }

  getLabelsSpecific(obj: any) {
    let arr= [];
    let myobj:any = {};

    for (let i = 0; i < obj.length; i++) {
      console.log(obj[i]['Category'] in Object.keys(myobj));
      
      if (!(obj[i]['Category'] in Object.keys(myobj))) {

        const one = obj[i]['Category'];
        myobj[obj[i]['Category']] = [{
            label: <any>[],
            value: <any>[]        
        }];

        for (let j = 0; j < obj.length; j++) {
          
          if (one === obj[j]['Category']) { 
            
            myobj[obj[i]['Category']][0].label.push(obj[j]['Sub-Category']); myobj[obj[i]['Category']][0].value.push(obj[j]['Quantity'])

          }
          
        }

      }
      

      arr.push(myobj)
      
    }

    

    return arr;
  }

  getValuesChart(obj: any) {
    let arr = [];
    
    for (let i = 0; i < obj.length; i++) {
      arr.push(obj[i].Quantity);      
    }

    return arr;
  }

  getValues() {
    this.report.getValue().subscribe(
      (s) => {
        console.log(s);
        this.reportData = s;
      }
    );
    console.log(this.reportData);    
  }


  setChart(label: any, data: any) {
    
    this.chart = new Chart(this.canvas.nativeElement.getContext('2d'), {
      type: 'doughnut',
    data: {
        labels: label,
        datasets: [{
            label: 'Evolution',
            data: data,/* 
            backgroundColor: [
              'rgba(255, 99, 132, 0.2)',
              'rgba(255, 159, 64, 0.2)',
              'rgba(255, 205, 86, 0.2)',
              'rgba(75, 192, 192, 0.2)',
              'rgba(54, 162, 235, 0.2)',
              'rgba(153, 102, 255, 0.2)',
              'rgba(201, 203, 207, 0.2)'
            ],
          borderColor: [
              'rgba(255, 99, 132, 1)',
              'rgba(54, 162, 235, 1)',
              'rgba(255, 206, 86, 1)',
              'rgba(75, 192, 192, 1)',
              'rgba(153, 102, 255, 1)',
              'rgba(255, 159, 64, 1)'
          ], */
            
            borderWidth: 1
        }]
    },
    options: {
      responsive: true
    }
      
  });
  }


  setChart2(label: any, data: any) {
    
    this.chart = new Chart(this.canvas2.nativeElement.getContext('2d'), {
      type: 'doughnut',
    data: {
        labels: label,
        datasets: [{
            label: 'Evolution',
            data: data,/* 
            backgroundColor: [
              'rgba(255, 99, 132, 0.2)',
              'rgba(255, 159, 64, 0.2)',
              'rgba(255, 205, 86, 0.2)',
              'rgba(75, 192, 192, 0.2)',
              'rgba(54, 162, 235, 0.2)',
              'rgba(153, 102, 255, 0.2)',
              'rgba(201, 203, 207, 0.2)'
            ],
          borderColor: [
              'rgba(255, 99, 132, 1)',
              'rgba(54, 162, 235, 1)',
              'rgba(255, 206, 86, 1)',
              'rgba(75, 192, 192, 1)',
              'rgba(153, 102, 255, 1)',
              'rgba(255, 159, 64, 1)'
          ], */
            
            borderWidth: 1
        }]
    },
    options: {
      responsive: true
    }
      
  });
  }

}
