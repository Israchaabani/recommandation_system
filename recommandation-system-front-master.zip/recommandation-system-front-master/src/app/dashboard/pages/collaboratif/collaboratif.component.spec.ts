import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CollaboratifComponent } from './collaboratif.component';

describe('CollaboratifComponent', () => {
  let component: CollaboratifComponent;
  let fixture: ComponentFixture<CollaboratifComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CollaboratifComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CollaboratifComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
