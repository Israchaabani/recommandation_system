import { Component, OnInit } from '@angular/core';
import { AnalyseService } from 'src/app/services/analyse.service';
import { Analyse } from 'src/app/models/Analyse.model';

@Component({
  selector: 'app-collaboratif',
  templateUrl: './collaboratif.component.html',
  styleUrls: ['./collaboratif.component.css']
})
export class CollaboratifComponent implements OnInit {
  file!: File;
  file2!: File;

  data: Analyse = {
    file: this.file,
    file2: this.file2,
    fileType: "excel",
    modelType: "collaborative_filtering",
    subCatg: "",
    quantity: "",
    catg: "",
    customerName: "",
    orderId: "",
    userId: ""
  };

  state = {
    loading: false,
    error: false,
    warn: false
  };

  stateAnimation = {
    spin: false,
    text1: false,
    text2: false,
    text3: false,
    text4: false
  };

  formData: FormData | undefined;
  result: any;
  score: any;

  dtOptions: any = {};

  constructor(private analyseService: AnalyseService) { }

  ngOnInit(): void {
    const user = localStorage.getItem("user-data");
    if (user) {
      this.data.userId = JSON.parse(user).id;
    }
    this.dtOptions = {
      // Declare the use of the extension in the dom parameter
      dom: 'Bfrtip',
      // Configure the buttons
      buttons: [
       
        'copy',
        'print',
        'excel'
      ]
   };
  }

  onLoadingFile(event:any) {
    //console.log(event.target.files[0]);    
    this.file = event.target.files[0];
    //console.log(this.file); 
    this.data.file = this.file;       
  }

  onLoadingFile2(event:any) {
    //console.log(event.target.files[0]);    
    this.file2 = event.target.files[0];
    //console.log(this.file); 
    this.data.file2 = this.file2;       
  }

  animation() {

    this.stateAnimation.spin = true;
    this.stateAnimation.text1 = true;
    window.scrollBy(0,500);

    setTimeout(() => {
      this.stateAnimation.text1 = false;
      this.stateAnimation.text2 = true;
    }, 1000);

    setTimeout(() => {
      this.stateAnimation.text2 = false;
      this.stateAnimation.text3 = true;
    }, 2000);


    setTimeout(() => {
      this.stateAnimation.text3 = false;
      this.stateAnimation.text4 = true;
    }, 3000);

    setTimeout(() => {
      this.stateAnimation.text4 = false;
      this.stateAnimation.spin = false;
      window.scrollBy(0,200);
    }, 4000);

  }

  condition() {
    if (this.data.file === undefined || this.data.file2 === undefined || this.data.catg === '' || this.data.orderId === ""  || this.data.customerName === "") {
      return false;
    }
    return true;
  }


  
  mlActivation() {
    this.state.warn = false;
    if (this.condition()) {
      this.state.loading = true;
    this.state.error = false;
    
    console.log(this.data);    
    console.log(typeof(this.data.file));
    
    this.formData = new FormData();
    this.formData.append('file', this.file);
    this.formData.append('file2', this.data.file2);
    this.formData.append('fileType', this.data.fileType);
    this.formData.append('modelType', this.data.modelType);
    //this.formData.append('subCatg', this.data.subCatg);
    //this.formData.append('quantity', this.data.quantity);
    this.formData.append('catg', this.data.catg);
    this.formData.append('customerName', this.data.customerName);
    this.formData.append('orderId', this.data.orderId);
    this.formData.append("userId", this.data.userId);
    
    this.analyseService.collaboratifRecommandModel(this.formData).subscribe(
      (s) => {
        console.log(s);
        this.state.loading = false;
        this.animation();
        this.result = s.data;
        this.score = s.score;
      }, (e) => {
        console.log(e);
        this.state.loading = false;
        this.state.error = true;
      }
    );
    } else {
      this.state.warn = true;
    }
    
  }

}
