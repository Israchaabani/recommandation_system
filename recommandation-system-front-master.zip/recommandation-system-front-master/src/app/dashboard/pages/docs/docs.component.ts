import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-docs',
  templateUrl: './docs.component.html',
  styleUrls: ['./docs.component.css']
})
export class DocsComponent implements OnInit {
snippet_res_1 = 
`
  {
    "by_sub_category": [
        {
            "Sub-Category": "YOUR-SUBCATEGORY",
            "Quantity": YOUR-QUANTITY
        },
        ...
    ],
    "by_category": [
        {
            "Category": "YOUR-CATEGORY"",
            "Quantity": YOUR-QUANTITY
        },
        ...
    ],
    "group_by": [
        {
            "Category": "YOUR-CATEGORY",
            "Sub-Category": "YOUR-SUBCATEGORY",
            "Quantity": YOUR-QUANTITY
        },
        ...
    ]
  }
`;

snippet_res_2 = 
`
  {
    "CUSTOMER-NAME": [
        "PRODUCT-NAME-OR-SUBCATEGORY",
        ...
    ],
    ...
  }
`;


snippet_res_3 = 
`
  {
    "CUSTOMER-NAME": [
        ["CATEGORY-NAME"]
    ],
    ....
  }
`;


snippet_nodjs =
`
  const https = require('https');
  const options = {
    hostname: 'https://APP_NAME/analyse',
    path: '/upload' // OR OTHERS ENDPOINT DEPENDING ON YOUR OBJECTIVE,
    method: 'POST',
    json: true,
    body: YOURJSONDATA
  };

  const req = https.request(options, res => {
    console.log('statusCode: ' +  res.statusCode);

    res.on('data', d => {
      process.stdout.write(d);
    });
  });

  req.on('error', error => {
    console.error(error);
  });
`;


snippet_python =
`
  # importing the requests library
  import requests
    
  # api-endpoint
  URL = "https://APP_NAME/analyse"

  # add the correct endpoint depending on your objective
  URL = URL + "/your-end-point"
    
  # defining json data with correct parameters
  jsonData = YOUR_JSON_DATA 
    
  # sending get request and saving the response as response object
  r = requests.get(url = URL, params = jsonData)
    
  # extracting data in json format
  data = r.json()
`;


snippet_php = 
`
  <?php
  function httpPost($url, $data){
      $curl = curl_init($url);
      curl_setopt($curl, CURLOPT_POST, true);
      curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($data));
      curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
      $response = curl_exec($curl);
      echo $response;
  }

  $data = [
      'KEY-JSON' => 'VALUE-DATA',
      ....
  ]; // MUST RESPECT THE FORMAT 

  $url = "https://APP_NAME/analyse" . "your-end-point"; // DEPENDING ON YOUR OBJECTIVE
  httpPost($url, $data);
  ?>
`;
  constructor() { }

  ngOnInit(): void {
  }

}
