import { Component, OnInit } from '@angular/core';
import { AnalyseService } from 'src/app/services/analyse.service';

@Component({
  selector: 'app-sidebar-dash',
  templateUrl: './sidebar-dash.component.html',
  styleUrls: ['./sidebar-dash.component.css']
})
export class SidebarDashComponent implements OnInit {
user: any;
aList: any;

  constructor(private analyseService: AnalyseService) { }

  ngOnInit(): void {
    const u = localStorage.getItem("user-data");
    if (u) {
      this.user = JSON.parse(u);

      this.getAnalysesList();
    }
  }


  getAnalysesList() {
    this.analyseService.getAnalysesList(this.user.id).subscribe(
      (s) => {
        console.log(s);
        this.aList = s;
      }, (e) => {
        console.log(e);
        
      }
    );
  }

}
