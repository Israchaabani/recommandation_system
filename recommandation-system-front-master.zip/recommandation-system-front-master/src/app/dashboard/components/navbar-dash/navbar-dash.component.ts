import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-navbar-dash',
  templateUrl: './navbar-dash.component.html',
  styleUrls: ['./navbar-dash.component.css']
})
export class NavbarDashComponent implements OnInit {
state = false;
user: any;
  constructor(private authService: AuthService, private router: Router) { }

  ngOnInit(): void {
    const token = localStorage.getItem('tokenisation');
    if (token) this.state = true;

    this.getUserData();

  }


  getUserData() {
    const user = localStorage.getItem('user-data');

    if (!user) {

      this.authService.getUserData().subscribe(
        (s) => {
          console.log(s);
          this.user = s;
          localStorage.setItem('user-data', JSON.stringify(s));
        }, (e) => {
          console.log(e);
          if (e.status === 403) this.logout();
        }
      );

    } else {
      this.user = JSON.parse(user);
    }
    
  }


  logout() {
    this.authService.logout().subscribe(
      (s) => {
        console.log(s);
        localStorage.removeItem('tokenisation');
        localStorage.removeItem('user-data');
        window.location.reload();
        this.router.navigateByUrl('/');
        
      }, (e) => {
        console.log(e);
        
      }
    )
  }
}
