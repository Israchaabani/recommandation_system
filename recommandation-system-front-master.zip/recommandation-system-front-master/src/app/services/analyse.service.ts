import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, retry } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AnalyseService {
  url = environment.endPoind + "analyse/";
  popularURL = this.url + "upload";
  relatedURL = this.url + "upload-2";
  collaboratifURL = this.url + "upload-3";
  getAnalysesURL = this.url + "get-analyses/";

  constructor(private http: HttpClient) { }


  popularRecommandModel(data: any): Observable<any> {
    return this.http.post(this.popularURL, data);
  }

  relatedRecommandModel(data: any): Observable<any> {
    return this.http.post(this.relatedURL, data);
  }

  collaboratifRecommandModel(data: any): Observable<any> {
    return this.http.post(this.collaboratifURL, data);
  }

  getAnalysesList(params: any): Observable<any> {
    return this.http.get(this.getAnalysesURL + "?id=" + params);
  }

}
