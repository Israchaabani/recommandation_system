import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor,
  HttpErrorResponse
} from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable()
export class HttpInterceptInterceptor implements HttpInterceptor {

  constructor() {}

  intercept(request: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> {

    const token = localStorage?.getItem("tokenisation");
    if (token) {
      console.log(token);
      
      return next.handle(request.clone({ setHeaders: {"Accept": "*/*", "jwt" : token,  } }));
    }
    return next.handle(request);
  }
}

function catchError(arg0: (error: HttpErrorResponse) => any): import("rxjs").OperatorFunction<HttpEvent<any>, HttpEvent<any>> {
  throw new Error('Function not implemented.');
}
