import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  url = environment.endPoind + "api/";

  loginURL = this.url + "login";
  registerURL = this.url + "register";
  logoutURL = this.url + "logout";
  userDataURL = this.url + "user";

  constructor(private http: HttpClient) { }

  login(data: any): Observable<any> {
    return this.http.post(this.loginURL, data);
  }


  register(data: any): Observable<any> {
    return this.http.post(this.registerURL, data);
  }

  logout(): Observable<any> {
    return this.http.post(this.logoutURL, {});
  }

  getUserData(): Observable<any> {
    return this.http.get(this.userDataURL);
  }

}
