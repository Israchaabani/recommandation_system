import { Injectable } from '@angular/core';
import {BehaviorSubject} from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ReportDataService {

  emitData = new BehaviorSubject({});
  currentEmitData = this.emitData.asObservable();

  constructor() { }

  setValue(object: any) {
    this.emitData.next(object);
  }

  getValue() {
    return this.currentEmitData;
  }
}
