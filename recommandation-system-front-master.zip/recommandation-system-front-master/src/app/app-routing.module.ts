import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './main/pages/home/home.component';
import { FeaturesComponent } from './main/pages/features/features.component';
import { LoginComponent } from './main/pages/login/login.component';
import { RegisterComponent } from './main/pages/register/register.component';
import { HomeAdminComponent } from './dashboard/pages/home-admin/home-admin.component';
import { PopularComponent } from './dashboard/pages/popular/popular.component';
import { RelatedComponent } from './dashboard/pages/related/related.component';
import { CollaboratifComponent } from './dashboard/pages/collaboratif/collaboratif.component';
import { GuardGuard } from './services/auth/guard.guard';
import { DocsComponent } from './dashboard/pages/docs/docs.component';
import { ReportComponent } from './dashboard/pages/report/report.component';

const routes: Routes = [
  {
    path: "",
    component: HomeComponent
  },
  {
    path: "feature",
    component:  FeaturesComponent
  },
  {
    path: "documentation",
    component: DocsComponent
  },
  {
    path: "sign-in",
    component: LoginComponent
  },
  {
    path: "sign-up",
    component: RegisterComponent
  },
  {
    path: "dashboard",
    component: HomeAdminComponent,
    canActivate: [GuardGuard]
  },
  {
    path: "popular-product",
    component: PopularComponent,
    canActivate: [GuardGuard]
  },
  {
    path: "related-product",
    component: RelatedComponent,
    canActivate: [GuardGuard]
  },
  {
    path: "collaborative-filtering",
    component: CollaboratifComponent,
    canActivate: [GuardGuard]
  },
  {
    path: "report",
    component: ReportComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { scrollPositionRestoration: "top"})],
  exports: [RouterModule]
})
export class AppRoutingModule { }
