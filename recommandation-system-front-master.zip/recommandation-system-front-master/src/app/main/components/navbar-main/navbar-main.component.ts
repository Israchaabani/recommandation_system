import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-navbar-main',
  templateUrl: './navbar-main.component.html',
  styleUrls: ['./navbar-main.component.css']
})
export class NavbarMainComponent implements OnInit {
state: any;
user: any;
  constructor(private authService: AuthService, private router: Router) { }

  ngOnInit(): void {
    const token = localStorage.getItem('tokenisation');
    if (token) this.state = true;

    const user = localStorage.getItem('user-data');
    if (user) this.user = JSON.parse(user);
  }


  logout() {
    this.authService.logout().subscribe(
      (s) => {
        console.log(s);
        localStorage.removeItem('tokenisation');
        localStorage.removeItem('user-data');
        this.router.navigateByUrl('/');
        window.location.reload();

      }, (e) => {
        console.log(e);
        
      }
    )
  }

}
