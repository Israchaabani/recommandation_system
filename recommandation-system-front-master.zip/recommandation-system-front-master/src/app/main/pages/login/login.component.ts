import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  state = {
    forms: false,
    loading: false,
    error: false
  };

  constructor(private authService: AuthService, private router: Router) { }

  ngOnInit(): void {
  }


  onSubmit(f: NgForm) {
      console.log(f.value);
      
      this.state.forms = false;
      this.state.error = false;
      
  
      if (f.valid) {
        this.state.loading = true;
  
        this.authService.login(f.value).subscribe(
          (s) => {
            console.log(s);
            localStorage.setItem('tokenisation', s.jwt);
            this.router.navigateByUrl("/dashboard");
            this.state.loading = false;
            // this.router.navigateByUrl("/sign-in");
  
          }, (e) => {
            console.log(e);
            this.state.error = true;
            this.state.loading = false;
          }
        );
      } else {
  
        this.state.forms = true;
  
      }
  }

}
