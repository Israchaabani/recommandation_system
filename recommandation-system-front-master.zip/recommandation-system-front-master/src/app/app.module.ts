import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './main/pages/home/home.component';
import { NavbarMainComponent } from './main/components/navbar-main/navbar-main.component';
import { FooterMainComponent } from './main/components/footer-main/footer-main.component';
import { FeaturesComponent } from './main/pages/features/features.component';
import { LoginComponent } from './main/pages/login/login.component';
import { RegisterComponent } from './main/pages/register/register.component';
import { NavbarDashComponent } from './dashboard/components/navbar-dash/navbar-dash.component';
import { FooterDashComponent } from './dashboard/components/footer-dash/footer-dash.component';
import { HomeAdminComponent } from './dashboard/pages/home-admin/home-admin.component';
import { SidebarDashComponent } from './dashboard/components/sidebar-dash/sidebar-dash.component';
import { DocsComponent } from './dashboard/pages/docs/docs.component';
import { PopularComponent } from './dashboard/pages/popular/popular.component';
import { RelatedComponent } from './dashboard/pages/related/related.component';
import { CollaboratifComponent } from './dashboard/pages/collaboratif/collaboratif.component';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { FormsModule} from '@angular/forms'
import { HttpInterceptInterceptor } from './services/auth/http-intercept.interceptor';
import { DataTablesModule } from 'angular-datatables';
import { SidebarMainComponent } from './main/components/sidebar-main/sidebar-main.component';
import { ReportComponent } from './dashboard/pages/report/report.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    NavbarMainComponent,
    FooterMainComponent,
    FeaturesComponent,
    LoginComponent,
    RegisterComponent,
    NavbarDashComponent,
    FooterDashComponent,
    HomeAdminComponent,
    SidebarDashComponent,
    DocsComponent,
    PopularComponent,
    RelatedComponent,
    CollaboratifComponent,
    SidebarMainComponent,
    ReportComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    DataTablesModule
  ],
  providers: [{ provide: HTTP_INTERCEPTORS, useClass: HttpInterceptInterceptor, multi: true }],
  bootstrap: [AppComponent]
})
export class AppModule { }
