export class Analyse {
    file!: File;
    file2! : File;
    fileType!: string;
    modelType!: string;
    subCatg!: string;
    quantity!: string;
    catg!: string;
    customerName!: string;
    orderId!: string;
    userId!: string
}