from django.db import models

# Create your models here.
class Analyse(models.Model):
    file = models.FileField(blank=True)
    file2 = models.FileField(blank=True)
    fileType = models.CharField(max_length=255)
    modelType = models.CharField(max_length=255, null=True)
    subCatg = models.CharField(max_length=255, blank=True)
    quantity = models.CharField(max_length=255, blank=True)
    catg = models.CharField(max_length=255)
    customerName = models.CharField(max_length=255, blank=True)
    orderId = models.CharField(max_length=255, blank=True)
    userId = models.CharField(max_length=255, null=True)
    timestamp = models.DateTimeField(auto_now_add=True)