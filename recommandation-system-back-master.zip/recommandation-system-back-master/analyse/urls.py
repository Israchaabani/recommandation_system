from django.urls import path
from .views import AnalyseView, Analyse2View, Analyse3View, AnalyseListView

urlpatterns = [
    path('upload', AnalyseView.as_view()),
    path('upload-2', Analyse2View.as_view()),
    path('upload-3', Analyse3View.as_view()),
    path('get-analyses/', AnalyseListView.as_view())
    #re_path(r'^upload/(?P<filename>[^/]+)$', AnalyseView.as_view()
]

