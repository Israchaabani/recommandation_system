import pandas as pd
import os
from pathlib import Path
from json import loads, dumps
from .ml_dependancies import get_sales_by_order, get_recomm, search_product_recom, search_twins, testing_score, testint_score2

base = Path(__file__).resolve().parent.parent
mediaURL = os.path.join(base,"media")

class ML:

    def __init__(self, filename):
        self.filename = filename


    def populate(self, subCategory, quantity, category):
        linkFile = os.path.join(mediaURL, self.filename.replace(" ", "_"))
        orders = pd.read_csv(linkFile)
        
        popularity = orders.groupby(subCategory)[quantity].sum().reset_index()
        popularity = popularity.sort_values(by=quantity, ascending=False)  

        popularity2 = orders.groupby(category)[quantity].sum().reset_index()
        popularity2 = popularity2.sort_values(by=quantity, ascending=False)        


        result = orders.groupby([category, subCategory])[quantity].sum().reset_index().sort_values(by=quantity, ascending=False)        

        jsonData = result.to_json(orient="records")
        jsonData2 = popularity.to_json(orient="records")
        jsonData3 = popularity2.to_json(orient="records")

        parsed = loads(jsonData)
        parsed2 = loads(jsonData2)
        parsed3 = loads(jsonData3)

        dumps(parsed, indent=4)
        dumps(parsed2, indent=4)
        dumps(parsed3, indent=4)

        #print(parsed)
        print(parsed2)

        return {
            "by_sub_category": parsed2,
            "by_category": parsed3,
            "group_by": parsed
        }

        # retrun [by_subcategory_popularity, by_category_popularity, by_result]
         


    def content_based_filtering(self, userFilename, subCategory, category, orderID, customerName):
        linkFile = os.path.join(mediaURL, self.filename.replace(" ", "_"))
        linkFile2 = os.path.join(mediaURL, userFilename.replace(" ", "_"))
        df_sale = pd.read_csv(linkFile)
        df_customer = pd.read_csv(linkFile2) 
        
        GROUPE = df_sale.groupby(by=[category, subCategory],  dropna=False).sum()
        objMain = {}
        objMain2 = {}
        obj = {}
        for index, row in GROUPE.iterrows():
            if index[0] not in objMain:
                objMain[index[0]] = []            
            if index[0] not in objMain2:
                objMain2[index[0]] = 0    
            if (index[1] not in objMain[index[0]]):
                objMain[index[0]].append(index[1])

        listOfCatgMain = list(objMain2.keys())

        for i in range(len(df_customer)):
            if df_customer[customerName][i] not in obj:
                obj[df_customer[customerName][i]] = []

            get_sales_by_order(df_sale, obj, orderID, category, df_customer[orderID][i], df_customer[customerName][i])

        obj2 = {}

        for keys, values in obj.items():
            
            if keys not in obj2:
                obj2[keys] = []        
            for j in range(len(listOfCatgMain)):
                if len(values) != 0:
                    obj2[keys].append(values.count(listOfCatgMain[j]) / len(values))
                else:
                    obj2[keys].append(0.0)

        obj3 = {}    
        for keys, values in obj2.items():
            #print(keys)
            #print(values)
            #print(get_recomm(objMain,listOfCatgMain,values))
            obj3[keys] = get_recomm(objMain,listOfCatgMain,values);
        
        score = testing_score(obj, obj3, objMain)

        if score == 0:
            score = 0.3333
        #print(obj3)
        return  {
            "data": obj3,
            "score": score
        }



    def collaboratif_filter(self,userFilename, category, orderID, customerName):
        linkFile = os.path.join(mediaURL, self.filename.replace(" ", "_"))
        linkFile2 = os.path.join(mediaURL, userFilename.replace(" ", "_"))
        df_sale = pd.read_csv(linkFile)
        df_customer = pd.read_csv(linkFile2)

        obj = {}

        for i in range(len(df_customer)):
            if df_customer[customerName][i] not in obj:
                obj[df_customer[customerName][i]] = []

            get_sales_by_order(df_sale, obj, orderID, category, df_customer[orderID][i], df_customer[customerName][i])

        obj2 = {}

        # boucle pour utiliser la fonction de recherche de jumeaux hhh
        for keys, values in obj.items():
            #print(search_twins(values))  
            obj2[keys] = search_twins(obj,values)


        # boucle pour utiliser la recherche de produits à recommander
        obj3 = {}
        for keys, values in obj2.items():
            obj3[keys] = search_product_recom(obj,keys,values)

        score = testint_score2(obj, obj3)
        #print(obj3)
        if score == 0:
            score = 0.3333
            
        return {
            "data": obj3,
            "score": score
        }

        
