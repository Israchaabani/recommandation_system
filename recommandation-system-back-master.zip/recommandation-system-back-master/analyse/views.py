from rest_framework.views import APIView
from rest_framework.parsers import MultiPartParser, FormParser, FileUploadParser, JSONParser
from rest_framework.response import Response
from rest_framework import status

from analyse.models import Analyse
from .serializers import AnalyseSerializer
from .ml import ML

# Create your views here.

class AnalyseView(APIView):
    parser_classes = [MultiPartParser, FormParser, JSONParser]
    #parser_classes = [FileUploadParser,]
    #parser_classes = [JSONParser, MultiPartParser]
    def post(self, request, format=None):
        print(request.data)
        print(request.FILES['file'].name)
        newData = ML(request.FILES['file'].name).populate(request.data['subCatg'], request.data['quantity'], request.data['catg'])
        serializer = AnalyseSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(newData, status=status.HTTP_200_OK)
        else:
            print(serializer.errors)

            return Response({"error": "problem"}, status=status.HTTP_400_BAD_REQUEST)


class Analyse2View(APIView):
    parser_classes = [MultiPartParser, FormParser, JSONParser]

    def post(self, request, format=None):
        print(request.FILES['file2'].name)
        newData = ML(request.FILES['file'].name).content_based_filtering(request.FILES['file2'].name, request.data['subCatg'],request.data['catg'], request.data['orderId'], request.data['customerName'])
        serializer = AnalyseSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(newData, status=status.HTTP_200_OK)
        else:
            print(serializer.errors)
            return Response({"error": "problem"}, status=status.HTTP_400_BAD_REQUEST)



class Analyse3View(APIView):
    parser_classes = [MultiPartParser, FormParser, JSONParser]

    def post(self, request, format=None):
        print(request.FILES['file2'].name)
        newData = ML(request.FILES['file'].name).collaboratif_filter(request.FILES['file2'].name,request.data['catg'],request.data['orderId'],request.data['customerName'])
        serializer = AnalyseSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(newData, status=status.HTTP_200_OK)
        else:
            return Response({"error": "problem"}, status=status.HTTP_400_BAD_REQUEST)
        


class AnalyseListView(APIView):

    def get(self, request):

        print(request.query_params.get('id'))
        if request.query_params:
            items = Analyse.objects.filter(userId=request.query_params.get('id'))
        

        if items:
            print(items)
            serializer = AnalyseSerializer(items, many=True)
            return Response(serializer.data)
        else:
            return Response(status=status.HTTP_404_NOT_FOUND)
