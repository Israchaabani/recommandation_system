from rest_framework import serializers
from .models import Analyse

class AnalyseSerializer(serializers.ModelSerializer):
    file = serializers.FileField(use_url=True)
    file2 = serializers.FileField(use_url=True, allow_empty_file=True, required=False)
    class Meta:
        model = Analyse
        fields = '__all__'
        #fields = ('id', 'file','file2', 'fileType', 'subCatg', 'quantity', 'catg', 'customerName', 'orderId', 'timestamp')
