# 1er etape : regrouper les ventes par user
def get_sales_by_order(df_sale, obj, order_id_label, category_label, order_id, customer_name):

    for i in range(len(df_sale)):
        if (df_sale[order_id_label][i] == order_id):
            obj[customer_name].append(df_sale[category_label][i])
  


# Niveau 1
def get_recomm(objMain, listOfCatgMain, json):
    final = []

    for i in range(len(json)):
        if json[i] >= 0.5:
            final += objMain[listOfCatgMain[i]]
    
    return final


# regrouper les users avec ceux qui ont les mêmes schémas de ventes (attention sans considéré la séquence)
def search_twins(obj, array):
    array_response = []
    for keys, values in obj.items():        
        if (len(array) !=0) and (all(element in values for element in array)):           
            array_response.append(keys)
    return array_response


# rechercher pour chaque user le produit qu'il n'a pas encore acheté en fonction de ses jumeaux hha :-)
def search_product_recom(obj, key,array):
    array_res = []
    for el in array:
        if ((set(obj[el]) - set(obj[key])) not in array_res):
            array_res.append(set(obj[el]) - set(obj[key]))
    return array_res


# afficher les produits à recommender (les catégories ici mais on peut le faire simplement avec les sous-catégories en remplacant a la ligne 18)
# mais il ya un peu de doublons 
def recommandation_print(obj):
    for keys, values in obj.items():
        print(keys)
        for i in values:
            el = list(i)
            if len(el) != 0:
                for j in el:
                    print("     --> {}".format(j))
        print()




# calcule du score niveau 1
def testing_score(obj, predictions, objMain):
    obj2 = {}
    
    for keys, values in obj.items():
        if keys not in obj2:
            obj2[keys] = []
            if (len(values) != 0):
                obj2[keys].append(values[len(values)-1])
                values.pop()
    for keys, values in obj2.items():
        if len(values) != 0:
            obj2[keys] = objMain[values[len(values) - 1]]

    true_number = 0
    false_number = 0
    for keys, values in obj2.items():
        if all(item in values for item in predictions[keys]):
            true_number+=1
        else:
            false_number+=1

    """ print("True : ", true_number/len(obj2)) 
    print("False : ", false_number/len(obj2)) """

    return true_number/len(obj2)



# calcule du score niveau 2
def testint_score2(obj, predictions):
    obj2 = {}
    for keys, values in obj.items():
        if keys not in obj2:
            obj2[keys] = []
            if (len(values) != 0):
                obj2[keys].append(values[len(values)-1])
                values.pop()
    
    print(obj2)
    true_number = 0
    false_number = 0
    for keys, values in obj2.items():
        if all(item in values for item in predictions[keys]):
            print(keys)
            true_number+=1
        else:
            false_number+=1
    # print("True : ", true_number/len(obj2)) 
    # print("False : ", false_number/len(obj2))

    return true_number/len(obj2)
